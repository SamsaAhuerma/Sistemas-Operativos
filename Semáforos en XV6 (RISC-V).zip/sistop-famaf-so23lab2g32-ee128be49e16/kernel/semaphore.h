
#define NMAX 11

int sem_down(int sem);

int sem_close(int sem);

int sem_open(int sem, int value);

int sem_up(int sem);